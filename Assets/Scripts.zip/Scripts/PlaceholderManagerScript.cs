﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaceholderManagerScript : MonoBehaviour {
    public bool IsEmpty { get; set; }
                                       
    // Use this for initialization
    void Start () {
        IsEmpty = true;

    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
